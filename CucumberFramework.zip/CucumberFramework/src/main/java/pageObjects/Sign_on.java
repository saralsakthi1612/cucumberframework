package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Sign_on {
	public Sign_on(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	@FindBy(name="userName")
	private WebElement txt_userName;
	
	@FindBy(name="password")
	private WebElement txt_password;
	
	@FindBy(name="login")
	private WebElement btn_login;
	
	public void Signon_action()
	{
		txt_userName.sendKeys("whitedevil161290");
		txt_password.sendKeys("whitedevil161290");
		btn_login.click();
		
	}
	

}
