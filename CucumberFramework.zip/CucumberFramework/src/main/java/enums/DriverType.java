package enums;

public enum DriverType {
	 CHROME, INTERNETEXPLORER, FIREFOX
}